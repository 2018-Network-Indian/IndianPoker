package indianClient;

import java.net.Socket;

public class Main {
	
	public static void main(String[] args) {
		
			LoginFrame test = new LoginFrame(); 
			//GameTable t = new GaqwewemeTable();
	} 

}
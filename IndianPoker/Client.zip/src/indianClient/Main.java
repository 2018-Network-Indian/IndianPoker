package indianClient;

import java.net.Socket;

public class Main {
	
	public static void main(String[] args) {
		
			LoginFrame test = new LoginFrame(); 
			//GreenRoom t = new GreenRoom();
	} 

}